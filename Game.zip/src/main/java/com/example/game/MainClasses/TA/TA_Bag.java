package com.example.game.MainClasses.TA;

import com.example.game.MainClasses.Hero;

public class TA_Bag extends Hero {

    double nX;
    double nY;

    public TA_Bag() {
        super(100, 50, 300,"TA");
    }

}
