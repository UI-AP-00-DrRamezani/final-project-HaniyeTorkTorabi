package com.example.game.MainClasses.TA;

import com.example.game.MainClasses.Hero;

public class TA_Phone extends Hero {

    double nX;
    double nY;

    public TA_Phone() {
        super(75, 125, 200, "TA");
    }

}
