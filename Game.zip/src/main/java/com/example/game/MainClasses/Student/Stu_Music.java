package com.example.game.MainClasses.Student;

import com.example.game.MainClasses.Hero;
import com.example.game.MainClasses.TA.TA_Bag;

public class Stu_Music extends Hero {

    double nX;
    double nY;

    public Stu_Music( ) {
        super(50, 150, 350,"Student");
    }
}
