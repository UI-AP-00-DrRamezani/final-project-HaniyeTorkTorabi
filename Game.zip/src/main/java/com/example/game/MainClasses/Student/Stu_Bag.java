package com.example.game.MainClasses.Student;

import com.example.game.MainClasses.Hero;
import com.example.game.MainClasses.TA.TA_Bag;

public class Stu_Bag extends Hero {

    double nX;
    double nY;

    public Stu_Bag() {
        super(100, 50, 300,"Student");

    }
}
