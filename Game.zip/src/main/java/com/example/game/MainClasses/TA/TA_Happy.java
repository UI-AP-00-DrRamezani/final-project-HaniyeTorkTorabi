package com.example.game.MainClasses.TA;

import com.example.game.MainClasses.Hero;

public class TA_Happy extends Hero {

    double nX;
    double nY;

    public TA_Happy() {
        super(100, 150, 400, "TA");
    }

}
