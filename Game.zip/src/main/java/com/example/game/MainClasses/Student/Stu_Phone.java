package com.example.game.MainClasses.Student;

import com.example.game.MainClasses.Hero;
import com.example.game.MainClasses.TA.TA_Bag;

public class Stu_Phone extends Hero {

    double nX;
    double nY;

    public Stu_Phone() {
        super(50, 50, 150, "Student");
    }

}
