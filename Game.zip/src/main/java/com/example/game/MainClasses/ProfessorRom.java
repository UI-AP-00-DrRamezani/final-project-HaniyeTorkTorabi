package com.example.game.MainClasses;

public class ProfessorRom {
    private double health;

    public ProfessorRom() {
        this.health = 1000;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }
}
